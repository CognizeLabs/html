# Agentic Readiness Playbook — Enterprise Rollout

For: AI architects rolling out agent-ready GitHub practices across an enterprise group where developers have mixed access to Claude Code, OpenAI Codex, and GitHub Copilot.

Companion artifact: the `agentic-ready-template/` repo scaffold (push it as an org-level GitHub template repository).

---

## 1. The core strategy: standardize on AGENTS.md

The fragmentation problem — some devs have Claude, some Codex, some Copilot — is solved by the **AGENTS.md open standard** (formalized August 2025, led by OpenAI with Google/Cursor/Factory; donated to the Linux Foundation's Agentic AI Foundation in December 2025). It is read natively by Codex, Copilot coding agent, Claude Code, Cursor, Gemini CLI, Aider, Devin, Amazon Q, and others — 60k+ repos use it.

The pattern the template implements:

- `AGENTS.md` at repo root = single source of truth (commands, style, testing rules, boundaries, definition of done).
- `CLAUDE.md` = one line: `@AGENTS.md` (Claude Code's import syntax).
- `.github/copilot-instructions.md` = pointer, so Copilot Chat and Copilot code review get the same rules the coding agent reads from AGENTS.md.
- Nested `AGENTS.md` in monorepo subfolders; the closest file wins.
- Path-scoped `.github/instructions/*.instructions.md` for special areas (e.g. security paths), with `applyTo` globs.

Result: every developer's agent — whichever vendor — operates under identical rules. That is the mechanism for "consistent quality regardless of tool."

## 2. What makes a repo agent-ready (beyond instruction files)

Instructions are necessary but not sufficient. Agents succeed where the **feedback loop** is tight:

1. **One-command environment** — `scripts/bootstrap.sh` + devcontainer. Clean checkout → passing tests in <10 min. This is the same environment Copilot coding agent and Codex cloud tasks spin up.
2. **Deterministic verification** — full test suite + lint runnable locally; CI runs the *identical* commands (no hidden steps). Flaky tests documented, quarantined.
3. **Trustworthy context** — short, current `docs/architecture.md`; ADRs for the "why". Stale docs are worse than none because agents believe them.
4. **Explicit boundaries** — do-not-modify paths, report-don't-fix zones, data-privacy rules. Critical in regulated/PII contexts.
5. **Scoped intake, verified output** — agent-ready issue template (goal, acceptance criteria, relevant files, out-of-scope, verification command) and a PR template requiring human line-by-line review + AI disclosure.

## 3. Governance layer (enterprise + org level)

Keep the enterprise layer thin; let teams own repo-level detail.

- **Template repo**: publish `agentic-ready-template` as an org template ("Use this template"); teams copy and adapt — promotes consistency without rigidity.
- **Rulesets + CODEOWNERS**: agent configuration files (`AGENTS.md`, `.mcp.json`, `.github/*`) dictate agent behavior — protect them so changes go through platform-team review via PR.
- **Branch protection**: CI green + ≥1 human review required everywhere; agents never merge autonomously.
- **Secret scanning push protection + dependency review** org-wide — agents introduce dependencies and occasionally secrets at machine speed.
- **Data privacy**: confirm each tool's enterprise data terms (no training on your code; zero-data-retention options where offered); classify repos and state handling rules in each AGENTS.md; synthetic data only in tests/fixtures/evals.
- **Copilot enterprise**: a `.github-private` repo can centralize custom agent profiles and permissions; Claude Code supports enterprise managed policy files that load before all project/user memory.
- **MCP servers**: treat like third-party libraries — reviewed, pinned, allowlisted centrally.

## 4. Rollout plan (suggested 90 days)

**Days 0–15 — Foundation.** Publish the template repo; protect it with rulesets; pick 2 pilot teams (one greenfield, one brownfield); baseline metrics (PR cycle time, revert rate, coverage).

**Days 15–45 — Pilot.** Greenfield team creates from template (docs/adoption/greenfield.md). Brownfield team follows the 3-phase incremental path (docs/adoption/brownfield.md) — instructions first, then verifiability, then workflow. Weekly retro; every recurring agent mistake becomes one line in that repo's AGENTS.md.

**Days 45–90 — Scale.** Publish pilot results + before/after AGENTS.md examples internally; run enablement sessions per tool cohort (Claude/Codex/Copilot) showing the *same* repo working with each; make agent-readiness a checklist item in production-readiness reviews; stand up a shared "instruction starters" library teams copy from.

**Ongoing.** Quarterly re-audit: are AGENTS.md files current? Are eval/test gates holding? Track AI-disclosure data from PR templates to see where agents help or hurt.

## 5. Greenfield vs brownfield vs agent-building — summary

| | Greenfield (new, small) | Brownfield (legacy) | Agent-building projects |
|---|---|---|---|
| Start | Create from template | Copy files incrementally | Template + agent-project layout |
| First priority | Fill placeholders before first feature | Boundaries: do-not-touch + report-don't-fix lists | Prompts/evals versioned as code |
| Documentation | Full from day one | Spec the **delta** each change touches; grow organically | `docs/agent-spec.md`: permissions, escalation, data flows |
| Agent autonomy | High early (low blast radius) | Start narrow: tests, docs, small fixes; expand as legibility grows | Evals gate merges; pinned models/MCP |
| Biggest risk | Placeholder rot | Agents "fixing" load-bearing workarounds; flaky tests | Prompt drift; real data leaking into evals |

## 6. Consistent quality: the mechanisms, not the slogan

Quality consistency comes from four enforced loops, tool-agnostic by design: same instructions (AGENTS.md), same environment (devcontainer/bootstrap), same verification (CI = local commands), same review bar (PR template + human review + protected config). A developer with Copilot and a developer with Claude Code working the same issue template in the same repo should produce interchangeable PRs — that's the test of readiness.

---

## Sources

- [AGENTS.md Complete Guide for Engineering Teams (2026)](https://blog.buildbetter.ai/agents-md-complete-guide-for-engineering-teams-in-2026/) · [AGENTS.md in 2026 — reviewable repo policy](https://windowsforum.com/threads/agents-md-in-2026-turning-agent-prompts-into-reviewable-repo-policy.430224/) · [Augment Code: How to Build Your AGENTS.md](https://www.augmentcode.com/guides/how-to-build-agents-md)
- [GitHub Changelog: Copilot coding agent supports AGENTS.md](https://github.blog/changelog/2025-08-28-copilot-coding-agent-now-supports-agents-md-custom-instructions/) · [.instructions.md support](https://github.blog/changelog/2025-07-23-github-copilot-coding-agent-now-supports-instructions-md-custom-instructions/) · [Agent-specific instructions](https://github.blog/changelog/2025-11-12-copilot-code-review-and-coding-agent-now-support-agent-specific-instructions/) · [GitHub Docs: repository custom instructions](https://docs.github.com/copilot/customizing-copilot/adding-custom-instructions-for-github-copilot)
- [Anthropic: Claude Code best practices](https://www.anthropic.com/engineering/claude-code-best-practices) · [CLAUDE.md memory hierarchy guide](https://deepwiki.com/FlorianBruniaux/claude-code-ultimate-guide/4.1-claude.md-files-and-memory-hierarchy)
- [A Practical Guide to Brownfield AI Development](https://thegeneralpartnership.substack.com/p/a-practical-guide-to-brownfield-ai) · [Augment Code: Spec-driven development for brownfield codebases](https://www.augmentcode.com/guides/spec-driven-development-brownfield-codebases) · [Copilot coding agent: agent-ready repos](https://agent-engine-optimization.com/docs/github-copilot-coding-agent-agent-ready-repos/) · [GitHub Docs: pilot the coding agent](https://docs.github.com/en/copilot/tutorials/coding-agent/pilot-coding-agent)
- [Governing AI agents in GitHub Enterprise](https://dev.to/devactivity/governing-ai-agents-boosting-engineering-productivity-with-secure-automation-in-github-enterprise-a0e) · [GitHub Docs: .github-private repository](https://docs.github.com/en/copilot/how-tos/administer-copilot/manage-for-enterprise/manage-agents/create-github-private-repo) · [GitHub community: governing AI agents](https://github.com/orgs/community/discussions/193359)
- [langwatch/better-agents repo structure](https://github.com/langwatch/better-agents/blob/main/docs/STRUCTURE.md) · [Structuring an AI agent repository](https://medium.com/@iduryodhanrao/a-practical-guide-to-structuring-an-ai-agent-repository-and-why-every-folder-matters-d1627a6dd022) · [agent-next/agent-ready scoring](https://github.com/agent-next/agent-ready)
