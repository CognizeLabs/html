# Agentic-Ready Repository Template

Org template for repos that work consistently well with AI coding agents — **Claude Code, OpenAI Codex, GitHub Copilot**, and anything else that reads `AGENTS.md`.

## Design principles

1. **One source of truth.** `AGENTS.md` (the Linux Foundation open standard, read natively by all three tools) holds all agent guidance. `CLAUDE.md` and `.github/copilot-instructions.md` are pointers — no drift between tools, no developer lottery based on which agent they were licensed.
2. **Verifiable by command.** Agents are only as good as their feedback loop: `bootstrap → build → test → lint` must work from a clean checkout, and CI runs the exact same commands.
3. **Explicit boundaries.** Do-not-touch paths, report-don't-fix areas, and data-privacy rules are written down and enforced (CODEOWNERS + rulesets), not tribal knowledge.
4. **Scoped work in, reviewed work out.** The issue template forces agent-sized scoping; the PR template forces human verification and AI disclosure.

## What's here

| Path | Purpose |
|---|---|
| `AGENTS.md` | Canonical agent instructions (fill the placeholders) |
| `CLAUDE.md` | Claude Code entry point → imports AGENTS.md |
| `.github/copilot-instructions.md` | Copilot Chat/code-review pointer → AGENTS.md |
| `.github/instructions/` | Path-scoped rules (example: security paths) |
| `.github/ISSUE_TEMPLATE/agent-task.yml` | Agent-ready task scoping |
| `.github/PULL_REQUEST_TEMPLATE.md` | Verification + AI disclosure |
| `.github/workflows/ci.yml` | Same commands as AGENTS.md |
| `.github/CODEOWNERS` | Protects agent-governance files |
| `.devcontainer/` | Reproducible environment for humans + agent sandboxes |
| `.mcp.json` | Project-scoped MCP servers (pinned, reviewed) |
| `scripts/bootstrap.sh` | Clean checkout → runnable, one command |
| `docs/architecture.md`, `docs/decisions/` | Context agents can trust; ADRs |
| `docs/adoption/` | Playbooks: greenfield, brownfield, agent-building projects |

## Using this template

- **New project**: "Use this template" → follow `docs/adoption/greenfield.md`.
- **Existing/legacy project**: copy files incrementally → follow `docs/adoption/brownfield.md`.
- **Building an AI agent**: base template + `docs/adoption/agent-projects.md`.

Search for `{{` to find every placeholder that must be filled.
