# Claude Code entry point — do not add content here.
@AGENTS.md
