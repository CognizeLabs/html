# AGENTS.md

<!-- Single source of truth for ALL AI coding agents (Claude Code, Codex, Copilot, Cursor, Gemini CLI, etc.).
     CLAUDE.md and .github/copilot-instructions.md are thin pointers to this file — edit HERE only.
     Keep this file under ~150 lines. Link out to docs/ for detail. -->

## Project overview

<!-- 2–4 sentences: what this service/app does, who consumes it, key architectural style.
     Example: "Payment reconciliation API. Consumed by the billing portal. Hexagonal architecture; domain logic in src/core, adapters in src/adapters." -->
- Purpose: {{ONE_SENTENCE_PURPOSE}}
- Architecture: {{ARCH_STYLE}} — see `docs/architecture.md`
- Key entry points: {{ENTRY_POINTS}}

## Setup, build, test commands

<!-- Agents run these verbatim. They MUST work from a clean checkout (verify in the devcontainer). -->
```bash
{{SETUP_COMMAND}}        # e.g. ./scripts/bootstrap.sh
{{BUILD_COMMAND}}        # e.g. make build
{{TEST_COMMAND}}         # e.g. make test  (full suite — must pass before any commit)
{{LINT_COMMAND}}         # e.g. make lint
{{SINGLE_TEST_COMMAND}}  # e.g. make test FILE=<path>  (fast inner loop)
```

## Code style and conventions

- Formatter/linter config is authoritative: {{LINT_CONFIG_FILES}}. Never hand-format against it.
- Naming: {{NAMING_CONVENTIONS}}
- Error handling: {{ERROR_HANDLING_PATTERN}}
- Follow existing patterns in the nearest module before inventing new ones.

## Testing rules

- Every behavior change requires a test. Bug fixes require a regression test that fails without the fix.
- Run `{{TEST_COMMAND}}` (full suite) before declaring work done — not a subset.
- Known-flaky tests: {{FLAKY_TESTS_OR_NONE}} — report flakes, don't "fix" them silently.

## Boundaries — read carefully

- **Do not modify:** {{PROTECTED_PATHS}} (e.g. `migrations/`, `vendor/`, generated code, this file's governance section).
- **Report, don't fix:** anything that looks like a bug in {{LOAD_BEARING_AREAS}}. Legacy workarounds here are load-bearing.
- **Never** commit secrets, credentials, `.env` files, or customer data. Never add dependencies without flagging them in the PR description.
- Data privacy: {{DATA_CLASSIFICATION_NOTE}} (e.g. "This repo processes PII — no real data in tests or fixtures.")

## Definition of done

1. Full test suite and lint pass locally.
2. New/changed behavior is covered by tests.
3. PR description states what changed, why, how it was verified, and which AI agent assisted.
4. No unrelated refactors bundled into the change.

## Repo map

<!-- Keep short; agents explore from here. -->
```
src/        {{SRC_DESCRIPTION}}
tests/      {{TESTS_DESCRIPTION}}
docs/       Architecture, ADRs, runbooks
scripts/    Bootstrap, CI helpers — the same commands CI runs
```

<!-- MONOREPOS: add nested AGENTS.md files in subprojects; the closest file to the edited code wins. -->
