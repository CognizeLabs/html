#!/usr/bin/env bash
# One command from clean checkout to runnable project.
# CI, devcontainer, and every AI agent use THIS script — keep it the single path.
set -euo pipefail

echo "Installing dependencies..."
# {{INSTALL_COMMANDS}}

echo "Bootstrap complete. Next: {{BUILD_COMMAND}} && {{TEST_COMMAND}}"
