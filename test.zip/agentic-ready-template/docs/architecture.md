# Architecture

<!-- The single doc agents are pointed to from AGENTS.md. Keep it current and short (1–2 pages).
     A stale architecture doc is worse than none — agents will trust it. -->

## System context

{{WHAT_THIS_SYSTEM_DOES_AND_ITS_NEIGHBORS}}

## Key components

| Component | Path | Responsibility |
|---|---|---|
| {{NAME}} | `src/{{...}}` | {{RESPONSIBILITY}} |

## Data flow

{{HOW_A_REQUEST_MOVES_THROUGH_THE_SYSTEM}}

## Invariants agents must preserve

- {{INVARIANT_1}}
- {{INVARIANT_2}}

## Decisions

See `docs/decisions/` for ADRs. Agents: check ADRs before proposing structural changes.
