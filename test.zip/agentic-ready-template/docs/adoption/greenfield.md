# Greenfield adoption path

New, smaller projects start agent-ready from day one. Create the repo **from this template**, then:

1. **Fill every `{{PLACEHOLDER}}`** in AGENTS.md, ci.yml, bootstrap.sh before the first feature commit. An AGENTS.md full of placeholders is worse than none.
2. **Prove the loop**: from a clean clone (or the devcontainer), run bootstrap → build → test. If that works, every agent can work here.
3. **Wire branch protection + rulesets** (org admin): require CI green, require human review, protect `AGENTS.md`, `.github/`, `.mcp.json` via CODEOWNERS.
4. **Write the first ADR** (why this stack/architecture) so agents don't second-guess foundational choices.
5. **File work as agent-ready issues** using the issue template from the start — it forces scoping discipline that benefits humans too.

Target: a developer (or agent) should go from `git clone` to a passing test run in under 10 minutes.
