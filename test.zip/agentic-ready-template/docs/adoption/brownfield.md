# Brownfield adoption path

Legacy repos adopt this template **incrementally** — copy files in, don't restructure the codebase first. Do NOT attempt to document everything upfront; grow coverage with each change.

## Phase 1 — Instructions (week 1, ~half a day)

1. Copy `AGENTS.md`, `CLAUDE.md`, `.github/copilot-instructions.md` into the repo root.
2. Fill in only what you know is true today: real build/test commands, the **"do not modify"** list, and the **"report, don't fix"** areas. In legacy code, the boundaries sections are the highest-value content — workarounds that look like bugs are often load-bearing.
3. Tip: run your agent of choice with a prompt like "explore this repo and draft AGENTS.md" — then have the tech lead correct it. The corrections are the valuable part.

## Phase 2 — Verifiability (weeks 2–4)

4. Make `bootstrap.sh` real: one command from clean checkout to running tests. This is usually the hardest and most valuable step.
5. Triage the test suite: quarantine or list known-flaky tests in AGENTS.md. Agents treat red tests as their fault and will "fix" them destructively.
6. Add the CI workflow so agents and humans share one definition of green.

## Phase 3 — Workflow (ongoing)

7. Adopt the issue and PR templates. Start agents on well-bounded tasks: test coverage, doc updates, small bug fixes with regression tests — not architectural changes.
8. Add nested `AGENTS.md` files to subsystems as agents touch them (spec the delta, not the whole system).
9. Each time an agent makes the same mistake twice, add one line to AGENTS.md. That feedback loop is the mechanism by which the repo becomes agent-ready.

## Anti-goals

- Don't refactor the codebase "to make it agent-friendly" before agents have delivered value.
- Don't let agents loose on modules with no test coverage — add characterization tests first (a good agent task in itself).
