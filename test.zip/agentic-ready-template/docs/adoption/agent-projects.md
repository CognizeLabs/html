# Repos that BUILD AI agents

Projects developing agents (automation / orchestrated-intelligence products) use the base template **plus** this structure. The principle: prompts, tools, and evals are production artifacts — versioned, reviewed, and tested like code.

## Additional structure

```
prompts/          # Versioned prompt files (YAML/MD), one file per prompt, semver in frontmatter
evals/            # Eval datasets + harness; run in CI like tests
  datasets/       #   Golden inputs/expected behaviors (NO real customer data)
  scenarios/      #   End-to-end agent scenario tests
tools/            # Tool/function definitions the agent can call, with schemas
guardrails/       # Input/output validation, policy filters
docs/agent-spec.md  # What the agent may/may not do; escalation + human-in-the-loop points
```

## Rules (add to this repo's AGENTS.md)

- **Prompts are config**: every prompt change is a PR with an eval run attached. No hot-editing prompts in dashboards.
- **Evals gate merges**: define a minimum eval pass rate in CI; a prompt/model change that regresses evals fails the build.
- **Pin models and MCP servers**: model IDs, temperatures, and third-party MCP servers are pinned versions — reviewed and audited like dependencies.
- **Data privacy**: eval datasets and fixtures use synthetic data only. Document data flows (what leaves the boundary, to which model provider, under which agreement) in `docs/agent-spec.md`.
- **Least privilege**: each tool the agent can call declares its scope; destructive tools require human confirmation paths.
- **Observability**: log agent decisions/tool calls (minus sensitive payloads) from day one.
