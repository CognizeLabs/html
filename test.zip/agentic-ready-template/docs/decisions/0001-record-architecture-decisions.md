# 1. Record architecture decisions

Date: {{DATE}}
Status: Accepted

## Context

AI agents and new developers need to know *why* the code is the way it is, not just *what* it is. Undocumented decisions get "helpfully" refactored away.

## Decision

We record significant architecture decisions as ADRs in `docs/decisions/`, numbered sequentially, using this format (Context / Decision / Consequences).

## Consequences

Agents are instructed (via AGENTS.md) to read ADRs before structural changes and to propose a new ADR when a task requires deviating from one.
