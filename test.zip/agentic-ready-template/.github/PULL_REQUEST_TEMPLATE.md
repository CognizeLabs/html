## What & why

<!-- Link the issue. One paragraph. -->

## How it was verified

- [ ] Full test suite passes locally (`{{TEST_COMMAND}}`)
- [ ] Lint passes
- [ ] New/changed behavior has tests
- [ ] I (a human) read every line of this diff

## AI assistance disclosure

- Agent(s) used: <!-- Claude Code / Codex / Copilot / none -->
- Autonomy level: <!-- pair-programmed | agent-drafted, human-reviewed | agent-autonomous -->

## Risk notes

<!-- New dependencies, security-sensitive paths touched, data handling changes — or "none". -->
