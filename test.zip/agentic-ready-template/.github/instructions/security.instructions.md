---
applyTo: "**/auth/**,**/security/**,**/*secret*"
---

# Security-sensitive paths

Changes under these paths require extra care: no new crypto implementations (use the approved library {{APPROVED_CRYPTO_LIB}}), no logging of tokens or PII, and every change must be called out explicitly in the PR description for security review.
