# GitHub Copilot instructions

All agent guidance lives in the root [AGENTS.md](../AGENTS.md). Read and follow it fully — setup/build/test commands, code style, testing rules, boundaries, and definition of done. Do not duplicate content here; this file exists so Copilot Chat and Copilot code review pick up the same rules the coding agent gets from AGENTS.md.
