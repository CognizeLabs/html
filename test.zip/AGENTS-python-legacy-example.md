# AGENTS.md — Legacy Python API (worked example)

<!-- EXAMPLE for a legacy Flask API ("orders-api"). Values are illustrative — replace with
     your repo's real ones, but keep the structure and the tone: specific, verifiable, honest
     about the legacy parts. Delete comments before committing. -->

## Project overview

- Purpose: Internal orders API. Serves the fulfillment portal and two partner integrations. In production since 2017.
- Stack: Python 3.9 (do NOT upgrade — pinned by the `legacy-soap` dependency), Flask 2.x, SQLAlchemy 1.4, PostgreSQL 13.
- Architecture: layered but inconsistent — newer code follows `app/services/` + `app/repositories/`; older code has business logic directly in `app/views/`. **Match the pattern of the file you're editing; do not migrate old code to the new pattern unless the task says so.**
- Key entry points: `app/wsgi.py` (prod), `app/views/` (route handlers).

## Setup, build, test commands

```bash
./scripts/bootstrap.sh                  # venv + pip install -r requirements.txt -r requirements-dev.txt
make test                               # pytest — full suite, ~4 min. Must pass before done.
make lint                               # ruff check . && ruff format --check .
pytest tests/unit/test_orders.py -x     # fast inner loop, single file
docker compose up -d db && make test-integration   # integration tests need local Postgres
```

- Dependencies are pinned in `requirements.txt`. Never add or bump a dependency without flagging it in the PR description.
- Python 3.9 syntax only: no `match` statements, no `X | Y` union types (use `typing.Optional`/`Union`).

## Code style and conventions

- `ruff.toml` is authoritative. Never hand-format against it.
- New code: type hints required, Google-style docstrings on public functions.
- Old code: do NOT add type hints or docstrings in drive-by fashion — only in functions you're already changing.
- Errors: raise `app.exceptions.ApiError` subclasses from services; views map them to HTTP responses in `app/error_handlers.py`. Never return raw 500s from views.
- Logging: `structlog` via `app.logging.get_logger()`. **Never log order payloads or customer fields — they contain PII.**

## Testing rules

- Every behavior change needs a test; bug fixes need a regression test that fails without the fix.
- Run the FULL suite (`make test`) before declaring work done, not just the files you touched.
- Known-flaky tests (do NOT attempt to fix; rerun once, then report):
  - `tests/integration/test_partner_webhooks.py::test_retry_backoff` (timing-sensitive)
  - `tests/unit/test_cache.py::test_ttl_expiry` (clock-dependent)
- Tests use factories in `tests/factories.py` with synthetic data only. Never paste real customer data into tests or fixtures.

## Boundaries — read carefully

- **Do not modify:**
  - `migrations/` (Alembic history is append-only — new migrations only, never edit existing ones)
  - `app/soap/` (generated client code — regenerate, don't hand-edit)
  - `app/utils/date_parse.py` (handles a partner's malformed timestamps; looks wrong, is load-bearing)
- **Report, don't fix:** anything that looks like a bug in `app/views/legacy_export.py` or the retry logic in `app/services/partner_sync.py`. These encode undocumented partner behavior. Describe the issue in your PR or the linked issue instead.
- Never commit secrets, `.env` files, or connection strings. Config comes from environment variables via `app/config.py`.

## Definition of done

1. `make lint` and `make test` pass locally.
2. New/changed behavior is covered by tests.
3. PR description: what changed, why, how verified, which AI agent assisted.
4. No unrelated refactors, formatting churn, or dependency changes bundled in.

## Repo map

```
app/views/        Route handlers (oldest code — highest caution)
app/services/     Business logic (newer pattern — prefer for new code)
app/repositories/ DB access via SQLAlchemy
app/soap/         Generated partner client — do not hand-edit
migrations/       Alembic — append-only
tests/            unit/ (no I/O) and integration/ (needs Postgres)
docs/             architecture.md, decisions/ (ADRs)
```
