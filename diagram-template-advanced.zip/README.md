# Architecture Diagram Template (Python → DrawIO + PNG)

This template generates **professional DrawIO diagrams** from a simple YAML instruction file,
with:

- ✅ CLI arguments (choose input & outputs)
- ✅ Automatic lane color palettes
- ✅ Support for external systems & security layers
- ✅ Optional PNG export (via local draw.io / diagrams.net CLI)

---

## 1. Install dependencies

```bash
pip install pyyaml
```

> Note: For PNG export, you also need the **draw.io / diagrams.net desktop app**
> installed and its CLI (`drawio`) available on your PATH.

---

## 2. Basic usage

Generate a `.drawio` file from the sample instructions:

```bash
python generate_diagram.py
```

This reads:

- `instructions/lingo_arch.yaml`

and writes:

- `output/lingo_arch.drawio`

Open the `.drawio` file in https://app.diagrams.net (or the desktop app) and tweak as needed.

---

## 3. CLI options

```bash
python generate_diagram.py \
  --input instructions/lingo_arch.yaml \
  --output-xml output/lingo_arch.drawio \
  --output-png output/lingo_arch.png
```

- `--input` — YAML spec file.
- `--output-xml` — DrawIO XML file (compatible with diagrams.net).
- `--output-png` — If provided, script will attempt to call the local `drawio` CLI
  to export a PNG.

If the `drawio` CLI is not available, the script will print a warning and skip PNG export.

---

## 4. YAML spec (instructions/lingo_arch.yaml)

Key sections:

- `layout`: controls sizes and spacing.
- `lanes`: top-to-bottom swimlanes (e.g., channels, APIs, services, data, external, security).
- `nodes`: components; each belongs to a `lane` and may have a `type`:
  - `service`, `channel`, `db`, `observability`, `external`, `security`, `gateway`, etc.
- `edges`: connections between nodes (`from`, `to`, `label`).

Example lane types (with pre-defined colors):

- `channel` – User Channels
- `api` – APIs & orchestration
- `service` – Domain services
- `data` – Data & observability
- `external` – External systems
- `security` – Security & compliance

Unknown lane types automatically get colors from a palette.

---

## 5. Extending for your team

- Copy `instructions/lingo_arch.yaml` to a new file, e.g. `instructions/my_solution.yaml`.
- Adjust the lanes, nodes, and edges to match your architecture.
- Run:

```bash
python generate_diagram.py --input instructions/my_solution.yaml --output-xml output/my_solution.drawio
```

- Optionally add `--output-png output/my_solution.png` if you want a PNG and have the draw.io CLI installed.

You now have a **repeatable, version-controlled** way to generate consistent architecture diagrams.
