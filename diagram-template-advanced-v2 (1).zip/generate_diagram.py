#!/usr/bin/env python3
"""Generate DrawIO (.drawio) and optional PNG from a YAML architecture spec.

This version:
- Uses CLI args (input, output-xml, output-png)
- Uses automatic lane palette + lane types
- Supports node types (channel, service, db, external, security, etc.)
- Uses column-based layout to reduce overlapping edges
- Uses orthogonal edge style for cleaner routing in DrawIO
"""

import argparse
import shutil
import subprocess
import xml.etree.ElementTree as ET
from pathlib import Path

import yaml

# ---------------- THEME / STYLE DEFINITIONS ---------------- #

LANE_PALETTE = [
    ("#f5f5f5", "#999999"),
    ("#e6f4ff", "#4a90e2"),
    ("#e8f5e9", "#43a047"),
    ("#fff8e1", "#f9a825"),
    ("#fce4ec", "#ec407a"),
    ("#ede7f6", "#7e57c2"),
]

LANE_TYPE_BASE = {
    "channel": ("#f5f5f5", "#999999"),
    "api": ("#e6f4ff", "#4a90e2"),
    "service": ("#e8f5e9", "#43a047"),
    "data": ("#fff8e1", "#f9a825"),
    "external": ("#fce4ec", "#ec407a"),
    "security": ("#ede7f6", "#7e57c2"),
}

NODE_TYPE_STYLES = {
    "default": "rounded=1;whiteSpace=wrap;html=1;fillColor=#ffffff;strokeColor=#4a90e2;fontSize=10;",
    "service": "rounded=1;whiteSpace=wrap;html=1;fillColor=#ffffff;strokeColor=#4a90e2;fontSize=10;",
    "channel": "rounded=1;whiteSpace=wrap;html=1;fillColor=#ffffff;strokeColor=#666666;fontStyle=1;fontSize=10;",
    "db": "shape=cylinder;whiteSpace=wrap;html=1;fillColor=#ffffff;strokeColor=#f57c00;fontSize=10;",
    "observability": "rounded=1;whiteSpace=wrap;html=1;fillColor=#ffffff;strokeColor=#6a1b9a;fontSize=10;",
    "external": "rounded=1;dashed=1;whiteSpace=wrap;html=1;fillColor=#ffffff;strokeColor=#ec407a;fontSize=10;",
    "security": "rounded=1;whiteSpace=wrap;html=1;fillColor=#ffffff;strokeColor=#7e57c2;fontStyle=1;fontSize=10;",
    "gateway": "rounded=1;whiteSpace=wrap;html=1;fillColor=#ffffff;strokeColor=#00897b;fontSize=10;",
}

EDGE_STYLE = (
    "endArrow=block;html=1;rounded=0;"
    "strokeColor=#4a90e2;fontSize=9;"
    "edgeStyle=orthogonalEdgeStyle;orthogonalLoop=1;"
)


# ---------------- CONFIG LOADING ---------------- #

def load_instructions(path: Path) -> dict:
    with path.open("r", encoding="utf-8") as f:
        return yaml.safe_load(f)


# ---------------- DRAWIO XML HELPERS ---------------- #

class IdGen:
    def __init__(self, start: int = 2) -> None:
        self.current = start

    def next(self) -> str:
        val = str(self.current)
        self.current += 1
        return val


def create_base_graph(title: str, diagram_id: str = "diagram1"):
    mxfile = ET.Element(
        "mxfile",
        attrib={
            "host": "app.diagrams.net",
            "agent": "python",
        },
    )
    diagram = ET.SubElement(
        mxfile,
        "diagram",
        attrib={"id": diagram_id, "name": title},
    )
    mxGraphModel = ET.SubElement(diagram, "mxGraphModel")
    root = ET.SubElement(mxGraphModel, "root")

    ET.SubElement(root, "mxCell", attrib={"id": "0"})
    ET.SubElement(root, "mxCell", attrib={"id": "1", "parent": "0"})

    return mxfile, root


def compute_lane_styles(lanes):
    styles_by_lane_id = {}
    palette_index = 0

    for lane in lanes:
        lane_id = lane["id"]
        lane_type = lane.get("type", "channel")

        if lane_type in LANE_TYPE_BASE:
            fill, stroke = LANE_TYPE_BASE[lane_type]
        else:
            fill, stroke = LANE_PALETTE[palette_index % len(LANE_PALETTE)]
            palette_index += 1

        style = (
            "swimlane;horizontal=1;rounded=1;whiteSpace=wrap;html=1;"
            f"fillColor={fill};strokeColor={stroke};fontStyle=1;"
        )
        styles_by_lane_id[lane_id] = style

    return styles_by_lane_id


def node_style_for_type(node_type: str) -> str:
    return NODE_TYPE_STYLES.get(node_type, NODE_TYPE_STYLES["default"])


def add_lane(root, id_gen: IdGen, lane_cfg, lane_index, layout, lane_styles):
    lane_id = id_gen.next()
    lane_cfg_id = lane_cfg["id"]
    style = lane_styles[lane_cfg_id]

    lane_height = layout["lane_height"]
    lane_gap = layout["lane_gap"]
    margin_x = layout["margin_x"]
    margin_y = layout["margin_y"]

    y = margin_y + lane_index * (lane_height + lane_gap)
    x = margin_x
    width = (
        layout["margin_x"]
        + 6 * (layout["node_width"] + layout["node_gap"])
    )

    lane_cell = ET.SubElement(
        root,
        "mxCell",
        attrib={
            "id": lane_id,
            "value": lane_cfg["label"],
            "style": style,
            "vertex": "1",
            "parent": "1",
        },
    )

    ET.SubElement(
        lane_cell,
        "mxGeometry",
        attrib={
            "x": str(x),
            "y": str(y),
            "width": str(width),
            "height": str(lane_height),
            "as": "geometry",
        },
    )

    return lane_id


def add_node(root, id_gen: IdGen, node_cfg, lane_cell_id, lane_index, layout):
    node_id = id_gen.next()
    node_type = node_cfg.get("type", "default")
    style = node_style_for_type(node_type)

    node_width = layout["node_width"]
    node_height = layout["node_height"]
    node_gap = layout["node_gap"]
    margin_x = layout["margin_x"]
    margin_y = layout["margin_y"]
    lane_height = layout["lane_height"]
    lane_gap = layout["lane_gap"]
    lane_header_height = layout["lane_header_height"]

    lane_y = margin_y + lane_index * (lane_height + lane_gap)
    y = lane_y + lane_header_height + 10

    col = node_cfg.get("col")
    if col is None:
        col = 0
    x = margin_x + col * (node_width + node_gap)

    node_cell = ET.SubElement(
        root,
        "mxCell",
        attrib={
            "id": node_id,
            "value": node_cfg["label"],
            "style": style,
            "vertex": "1",
            "parent": lane_cell_id,
        },
    )

    ET.SubElement(
        node_cell,
        "mxGeometry",
        attrib={
            "x": str(x),
            "y": str(y),
            "width": str(node_width),
            "height": str(node_height),
            "as": "geometry",
        },
    )

    return node_id


def add_edge(root, id_gen: IdGen, edge_cfg, node_id_map):
    edge_id = id_gen.next()
    src = node_id_map[edge_cfg["from"]]
    tgt = node_id_map[edge_cfg["to"]]
    label = edge_cfg.get("label", "")

    edge_cell = ET.SubElement(
        root,
        "mxCell",
        attrib={
            "id": edge_id,
            "value": label,
            "style": EDGE_STYLE,
            "edge": "1",
            "parent": "1",
            "source": src,
            "target": tgt,
        },
    )

    ET.SubElement(
        edge_cell,
        "mxGeometry",
        attrib={"relative": "1", "as": "geometry"},
    )

    return edge_id


def render_png_with_drawio(drawio_xml: Path, png_path: Path) -> bool:
    candidates = ["drawio", "draw.io", "drawio-desktop", "diagrams.net"]
    cli = None
    for c in candidates:
        if shutil.which(c):
            cli = c
            break

    if cli is None:
        print(
            "[WARN] No draw.io CLI found on PATH. "
            "Install draw.io desktop and ensure the 'drawio' command is available "
            "if you want automatic PNG export."
        )
        return False

    png_path.parent.mkdir(parents=True, exist_ok=True)

    try:
        subprocess.run(
            [
                cli,
                "--export",
                "--format",
                "png",
                "--output",
                str(png_path),
                str(drawio_xml),
            ],
            check=True,
        )
        print(f"[OK] PNG generated at: {png_path}")
        return True
    except subprocess.CalledProcessError as exc:
        print(f"[ERROR] draw.io CLI failed: {exc}")
        return False


def generate_drawio_from_yaml(yaml_path: Path, output_xml: Path) -> None:
    cfg = load_instructions(yaml_path)

    title = cfg.get("title", "Architecture Diagram")
    diagram_id = cfg.get("diagram_id", "diagram1")
    layout = cfg.get("layout", {})

    defaults = {
        "lane_height": 160,
        "lane_gap": 30,
        "node_width": 150,
        "node_height": 60,
        "node_gap": 40,
        "margin_x": 40,
        "margin_y": 40,
        "lane_header_height": 30,
    }
    for k, v in defaults.items():
        layout.setdefault(k, v)

    lanes = cfg.get("lanes", [])
    nodes = cfg.get("nodes", [])
    edges = cfg.get("edges", [])

    mxfile, root = create_base_graph(title, diagram_id)
    id_gen = IdGen()

    lane_styles = compute_lane_styles(lanes)

    lane_id_by_cfg_id = {}
    for lane_index, lane_cfg in enumerate(lanes):
        lane_cell_id = add_lane(
            root,
            id_gen,
            lane_cfg,
            lane_index,
            layout,
            lane_styles,
        )
        lane_id_by_cfg_id[lane_cfg["id"]] = lane_cell_id

    node_id_map = {}
    lane_index_map = {lane["id"]: idx for idx, lane in enumerate(lanes)}

    for node_cfg in nodes:
        lane_key = node_cfg["lane"]
        lane_cell_id = lane_id_by_cfg_id[lane_key]
        lane_index = lane_index_map[lane_key]

        cell_id = add_node(
            root,
            id_gen,
            node_cfg,
            lane_cell_id,
            lane_index,
            layout,
        )
        node_id_map[node_cfg["id"]] = cell_id

    for edge_cfg in edges:
        add_edge(root, id_gen, edge_cfg, node_id_map)

    output_xml.parent.mkdir(parents=True, exist_ok=True)
    tree = ET.ElementTree(mxfile)
    tree.write(output_xml, encoding="utf-8", xml_declaration=True)

    print(f"[OK] DrawIO XML generated at: {output_xml}")


def main():
    parser = argparse.ArgumentParser(
        description="Generate DrawIO architecture diagram from a YAML spec (clean layout)."
    )
    parser.add_argument(
        "-i",
        "--input",
        type=Path,
        default=Path("instructions/lingo_arch.yaml"),
        help="Path to YAML instruction file.",
    )
    parser.add_argument(
        "--output-xml",
        type=Path,
        default=Path("output/lingo_arch.drawio"),
        help="Output DrawIO XML file path.",
    )
    parser.add_argument(
        "--output-png",
        type=Path,
        default=None,
        help="Optional PNG output path (requires draw.io CLI).",
    )

    args = parser.parse_args()

    generate_drawio_from_yaml(args.input, args.output_xml)

    if args.output_png is not None:
        render_png_with_drawio(args.output_xml, args.output_png)


if __name__ == "__main__":
    main()
