# Architecture Diagram Template (Clean Layout – Python → DrawIO + PNG)

This version is tuned to produce **much cleaner diagrams**:

- Column-based layout: nodes are placed on a grid (lane, column) to reduce crossing lines.
- Orthogonal edges: edges prefer right-angles in DrawIO, making flows easier to read.
- Lane theming: channels, APIs, services, data, external systems, and security get distinct colors.
- CLI support: choose input YAML, DrawIO XML, and optional PNG output.

---

## 1. Dependencies

```bash
pip install pyyaml
```

> PNG export also requires the draw.io / diagrams.net desktop app with a `drawio` CLI available on PATH (optional).

---

## 2. Basic usage

```bash
python generate_diagram.py
```

This will:

- Read:  `instructions/lingo_arch.yaml`
- Write: `output/lingo_arch.drawio`

Open the `.drawio` file in https://app.diagrams.net and you should see a clean, left-to-right architecture with minimal overlapping lines.

---

## 3. With PNG export

```bash
python generate_diagram.py \
  --input instructions/lingo_arch.yaml \
  --output-xml output/lingo_arch.drawio \
  --output-png output/lingo_arch.png
```

If a `drawio` CLI is detected, a PNG will also be exported.

---

## 4. Controlling layout with columns

Each node can specify a `col`:

```yaml
nodes:
  - id: broker_portal
    label: "Broker Portal"
    lane: channels
    type: "channel"
    col: 0
```

- `lane` → which swimlane (row).
- `col` → which column (left-to-right).
- The generator uses `(lane, col)` as a grid, which keeps edges mostly vertical/horizontal.

If `col` is omitted, the node falls back to column 0.

---

## 5. Extending for your solutions

1. Copy `instructions/lingo_arch.yaml` → `instructions/my_solution.yaml`.
2. Adjust:
   - `lanes` (rows)
   - `nodes` (components, with `lane` + `col`)
   - `edges` (connections)
3. Run:

```bash
python generate_diagram.py --input instructions/my_solution.yaml --output-xml output/my_solution.drawio
```

You now have a **reusable, clean, and version-controlled** way to generate architecture diagrams with minimal line overlap.
