import asyncio
import json
from rich import print as rprint
from app.graph import build_graph
from app.ingestion.grab import grab_overnight_messages

async def run():
    messages = await grab_overnight_messages(hours=8)
    graph = build_graph()
    result = await graph.arun({"messages": messages})
    rprint("[bold green]--- Assistant Output ---[/]")
    rprint(json.dumps(result, indent=2, default=str))

if __name__ == "__main__":
    asyncio.run(run())
