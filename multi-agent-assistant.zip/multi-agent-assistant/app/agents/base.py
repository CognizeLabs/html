class BaseAgent:
    """All agents should inherit from this."""

    async def __call__(self, *args, **kwargs):
        raise NotImplementedError
