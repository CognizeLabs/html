import os
from langchain.chat_models import ChatOpenAI
from langchain.output_parsers import PydanticOutputParser
from .base import BaseAgent
from app.models import ParseOutput

SYSTEM_PROMPT = """You are an executive assistant.
Classify each incoming message as FYI or TODO.
For TODOs extract description, owner (if any), and due date (if stated).
Return JSON that matches the given schema.
"""

class ParserAgent(BaseAgent):
    def __init__(self, llm=None):
        self.llm = llm or ChatOpenAI(
            model=os.getenv("OPENAI_MODEL_NAME", "llama3"),
            base_url=os.getenv("OPENAI_API_BASE"),
            temperature=0.1,
        )
        self.parser = PydanticOutputParser(pydantic_object=ParseOutput)

    async def __call__(self, messages):
        content = "\n\n".join([m["body"] for m in messages])
        prompt = f"{SYSTEM_PROMPT}\n{self.parser.get_format_instructions()}\n{content}"
        completion = await self.llm.ainvoke(prompt)
        return self.parser.parse(completion)
