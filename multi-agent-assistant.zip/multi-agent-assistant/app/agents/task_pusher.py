from .base import BaseAgent
import json

class TaskPusherAgent(BaseAgent):
    """Transforms tasks into Jira / Planner payloads (stub)."""

    async def __call__(self, state):
        todos = state.get("todos", [])
        # For now just echo JSON for inspection
        jira_payloads = [
            {"summary": t.description, "assignee": t.owner, "due": t.due.isoformat() if t.due else None}
            for t in todos
        ]
        print("[TaskPusher] Would push:", json.dumps(jira_payloads, indent=2))
        return {"jira_payloads": jira_payloads}
