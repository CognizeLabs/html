from .base import BaseAgent
from datetime import datetime

class DigestAgent(BaseAgent):
    """Formats FYI messages into an HTML digest."""

    async def __call__(self, state):
        fyi = state.get("fyi", [])
        bullets = [f"<li><b>{msg['sender']}</b>: {msg['subject']}</li>" for msg in fyi]
        html = (
            f"<h3>Morning Briefing – {datetime.utcnow().date()}</h3>\n<ul>\n" +
            "\n".join(bullets) + "\n</ul>"
        )
        return {"digest_html": html}
