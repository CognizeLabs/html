import os
from dotenv import load_dotenv

load_dotenv()
LLM_MODEL = os.getenv("OPENAI_MODEL_NAME", "llama3")
LLM_BASE = os.getenv("OPENAI_API_BASE", "http://localhost:11434/v1")
