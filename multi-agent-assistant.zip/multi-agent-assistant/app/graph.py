from langgraph.graph import MessageGraph
from app.agents.parser import ParserAgent
from app.agents.digest import DigestAgent
from app.agents.task_pusher import TaskPusherAgent

def build_graph():
    g = MessageGraph()
    g.add_node("parse", ParserAgent())
    g.add_node("digest", DigestAgent())
    g.add_node("tasks", TaskPusherAgent())

    def route(state):
        if state.get("todos"):
            return "tasks"
        return "digest"

    g.add_edge("parse", route)
    g.add_edge("tasks", "END")
    g.add_edge("digest", "END")
    g.set_entry_point("parse")
    return g
