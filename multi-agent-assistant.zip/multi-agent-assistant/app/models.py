from datetime import datetime
from pydantic import BaseModel, Field
from typing import List, Optional

class Message(BaseModel):
    id: str
    sender: str
    subject: str
    body: str
    received_at: datetime

class Task(BaseModel):
    description: str
    owner: Optional[str] = None
    due: Optional[datetime] = None
    source_msg_id: str = Field(..., description="Originating message ID")

class ParseOutput(BaseModel):
    fyi: List[Message] = []
    todos: List[Task] = []
