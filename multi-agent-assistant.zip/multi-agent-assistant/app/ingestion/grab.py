from datetime import datetime, timedelta
import uuid

async def grab_overnight_messages(hours: int = 8):
    """Stub that returns fake messages until real API integration."""
    now = datetime.utcnow()
    msg = {
        "id": str(uuid.uuid4()),
        "sender": "teammate@example.com",
        "subject": "Draft metrics deck ready",
        "body": "Can you review the deck by EOD tomorrow? Thanks!",
        "received_at": (now - timedelta(hours=1)).isoformat(),
    }
    return [msg]
