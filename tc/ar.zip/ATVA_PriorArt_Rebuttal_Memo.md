---
title: "Prior-Art Rebuttal Memorandum"
subtitle: "Adaptive Trust Vector Arbitration (ATVA) vs. EigenTrust and Fisher–Rao Calibration"
author: "Confidential — Attorney–Client Privileged / Patent Prosecution Work Product"
date: "2026-06-09"
---

> **Purpose.** Pre-rebut the two references most likely to be cited against ATVA in a §102 (anticipation) or §103 (obviousness) rejection: (1) **EigenTrust** and (2) **Fisher–Rao post-hoc calibration**. This memo identifies, claim-by-claim, the limitations absent from each reference and the non-obviousness arguments. It is attorney work product to support drafting and prosecution; it is **not** a legal opinion or an admission of prior art.

---

## 1. The References

### 1.1 Reference A — EigenTrust
Kamvar, Schlosser & Garcia-Molina, *"The EigenTrust Algorithm for Reputation Management in P2P Networks,"* WWW 2003.

**What it teaches.** Each peer $i$ computes a *scalar* local trust $s_{ij}$ toward peer $j$ from satisfactory/unsatisfactory file transactions. Normalizing these yields a stochastic matrix $C$; the **global trust vector is its left principal eigenvector** $\vec t = C^\top \vec t$, computed by distributed power iteration. Transitive trust ("I trust whom my trusted peers trust") makes the system robust to malicious collectives. **Domain:** authenticity reputation in peer-to-peer file sharing.

**What it does NOT teach.** Multidimensional trust; calibration of confidence; any statistical-manifold (Fisher–Rao) geometry; regulatory-compliance estimation; consensus-*stability* measurement; non-stationary reliability tracking; learning the trust geometry from human overrides; arbitration among *categorical decisions* (approve/deny/escalate). EigenTrust outputs a *ranking of peers*, not a *gated decision with reconciled confidence*.

### 1.2 Reference B — Fisher–Rao Post-Hoc Calibration
Information-geometry calibration literature, including 2025 work treating a classifier's softmax output as a point on the probability simplex equipped with the **Fisher–Rao metric**, using additive-log-ratio (ALR) calibration maps (reducing to Platt scaling in the binary case) and geometric reliability = Fisher–Rao distance to simplex vertices.

**What it teaches.** Post-hoc calibration and uncertainty quantification of a **single model's** probability outputs using Fisher–Rao geometry on the simplex.

**What it does NOT teach.** Any multi-agent setting; any graph or arbitration; using the Fisher–Rao metric as a **between-agent affinity kernel**; spectral/eigenvector aggregation; stability gating; regulatory risk; online learning of the metric tensor from human overrides; reliability state estimation.

---

## 2. The Anticipated Rejection Theory (and why it fails)

A worst-case examiner argues: *"EigenTrust supplies eigenvector-based trust aggregation; Fisher–Rao calibration supplies the confidence geometry; combining them yields ATVA (§103)."* This theory fails on three independent grounds, developed per-claim in Section 3:

1. **Missing limitations.** Even the *union* of A and B lacks ATVA's consensus-**stability gate** (N4), **regulatory-risk gate**, **CUSUM/Kalman** reliability dynamics (N5), **regret-bounded** reweighting (N6), **trust-ANOVA** reconciliation (N7), and **override-driven metric learning** (N8). A combination that still omits claimed limitations cannot anticipate or render obvious.
2. **No motivation to combine.** A is a P2P *file-authenticity* reputation protocol; B is *single-model classifier* calibration. They are in different fields, solve different problems, and share no interface. The only roadmap from A+B to ATVA is **ATVA's own disclosure** — impermissible hindsight (*Graham/KSR* still bars hindsight reconstruction).
3. **Different function of shared math.** ATVA does not use Fisher–Rao to calibrate one model's outputs (B's function) nor eigenvectors to rank peers by file authenticity (A's function); it uses Fisher–Rao as the **edge kernel of an inter-agent affinity graph** whose eigenvector is then **gated** by stability and compliance. Repurposing a known operator to a new function with a new result weighs toward non-obviousness.

---

## 3. Claim-by-Claim Differentiation

*Claim labels below correspond to the candidate independent claims for ATVA. Essential limitations are summarized; counsel will formalize wording.*

### Claim 1 — Integrated arbitration method (anchor)
**Essential limitations.** (a) compute, per agent, a 6-D **calibrated** trust vector via per-agent/per-dimension logistic maps; (b) measure inter-agent distance under a **learned Fisher–Rao regulatory-weighted metric**; (c) form a trust-affinity Markov operator and take its **stationary distribution** as influence; (d) compute a **Consensus Stability Score** = spectral gap × margin; (e) compute a **regulatory-risk index**; (f) emit a decision **gated** to ESCALATE when stability or compliance thresholds fail, with a reconciled trust vector and confidence.

| Limitation | EigenTrust (A) | Fisher–Rao cal. (B) | A + B |
|---|---|---|---|
| (a) calibrated multi-dim trust vector | ✗ (scalar) | partial (single model, not per-agent) | ✗ |
| (b) Fisher–Rao **inter-agent** metric | ✗ | ✗ (intra-model) | ✗ |
| (c) trust-affinity stationary influence | partial (eigenvector, but file-authenticity scalar) | ✗ | partial |
| (d) stability gate (gap × margin) | ✗ | ✗ | ✗ |
| (e) regulatory-risk gate | ✗ | ✗ | ✗ |
| (f) stability/compliance-gated decision | ✗ | ✗ | ✗ |

**Conclusion:** Limitations (b), (d), (e), (f) are absent from A, B, and A+B. Claim 1 is neither anticipated nor obvious.

### Claim 2 — Fisher–Rao affinity kernel (N2)
**Essential limitation.** Edge weight between agents $i,j$ is $\exp(-d_{\mathbf G}(\mathbf{TV}_i,\mathbf{TV}_j))$ where $\mathbf G$ is the **Bernoulli Fisher–Rao tensor weighted by regulatory importance $\lambda_d$ and a coupling $\Lambda$ learned from overrides**.
**Differentiation.** B applies Fisher–Rao *within one model's simplex* for calibration — there is no second model, no pairwise distance, no kernel, and no $\lambda/\Lambda$ learned from human overrides. A has no statistical-manifold geometry at all. The *inter-agent kernel with a regulator-/override-learned tensor* is taught by neither and is not a predictable use of B.

### Claim 3 — Consensus Stability Score escalation gate (N4)
**Essential limitation.** Derive $\mathrm{CSS}=(1-|\lambda_2(\mathbf P)|)\cdot \text{margin}$ from the **second eigenvalue** of the affinity operator and the top-two decision margin, and **force escalation** when $\mathrm{CSS}<\theta$.
**Differentiation.** Neither reference computes or uses a *spectral gap* of an arbitration operator, a *decision margin*, or any *stability-triggered escalation*. EigenTrust uses only the principal eigenvector and discards $\lambda_2$. This limitation is wholly absent and produces a behavior (escalating a fragile plurality that would otherwise "win") that the prior art cannot achieve.

### Claim 4 — Stability-gated reconciliation + trust-ANOVA (N7)
**Essential limitation.** Reconciled confidence $C^{*}=\langle \mathbf w,\mathbf{TV}^{*}\rangle\cdot \mathrm{CSS}$ (confidence **multiplied** by stability), plus an ANOVA-style variance decomposition $\Upsilon_d$ identifying the **dimension responsible for disagreement**.
**Differentiation.** No reference multiplies aggregate confidence by a consensus-stability term, and none performs a between-/within-group variance decomposition over trust dimensions to explain disagreement. Absent from A, B, A+B.

### Claim 5 — Override-driven metric learning + reliability dynamics (N5, N6, N8)
**Essential limitation.** Human overrides (i) update per-agent logistic calibration by online gradient; (ii) update the **metric tensor** $\lambda,\Lambda$ from the rationale embedding; (iii) drive a **mean-reverting Kalman** reliability state with **CUSUM** change detection; and (iv) update dimension weights by **Hedge** with a regret bound.
**Differentiation.** EigenTrust updates scalar reputation from transaction outcomes only — no calibration, no metric learning, no Kalman/CUSUM, no human rationale. Fisher–Rao calibration is post-hoc and static with respect to human overrides. The **co-adaptation of geometry + calibration + reliability state from a single human-override signal** is taught by neither.

---

## 4. §103 Combination Rebuttal (consolidated)

1. **Non-analogous art / no motivation.** P2P file-reputation (A) and single-model calibration (B) are not reasonably pertinent to one another or to multi-agent regulated arbitration. A skilled artisan in regulated-AI arbitration would not look to a 2003 file-sharing reputation protocol for a calibration geometry, nor to a classifier-calibration paper for a consensus mechanism. *KSR* requires an apparent reason to combine; none exists outside hindsight.
2. **Combination still short of the claims.** As tabulated in Section 3, A+B omits the stability gate, regulatory-risk gate, gated reconciliation, override-driven metric learning, and reliability dynamics. A §103 combination that fails to teach all limitations is legally insufficient.
3. **Repurposing yields a new function and result.** ATVA's use of Fisher–Rao distance as an *inter-agent edge kernel*, and of the *spectral gap* as an *escalation trigger*, are new functions of known operators producing a new, measurable result (Section 5) — a recognized indicator of non-obviousness.
4. **Teaching away on a key point.** EigenTrust's design goal is to *converge to a single dominant trust ranking and suppress minorities*; ATVA deliberately **preserves and escalates high-magnitude minority/dissent signals** when stability is low (lone-expert and fragile-plurality handling). The prior art's express objective points away from ATVA's stability-gating behavior.

---

## 5. Secondary Considerations (objective indicia of non-obviousness)

| Indicium | Support for ATVA |
|----------|------------------|
| Unexpected results | Plurality-winning decisions are *correctly escalated* when consensus is geometrically fragile (see worked A/B/C example: APPROVE leads with 0.518 influence yet the system escalates) — a result voting/averaging/EigenTrust cannot produce |
| Measurable improvement | >40% hallucination reduction, >25% override reduction, calibration error <0.08, decision stability >95% (targets; Section 7 of intake form) |
| Long-felt, unmet need | Regulated-AI deployments (healthcare-insurance adjudication) require auditable, compliance-gated arbitration that the cited art does not provide |
| Skepticism / complexity | Combining calibration geometry with spectral arbitration and online metric learning is non-trivial and not suggested by the references |

---

## 6. Drafting Recommendations

- **Foreground the gates.** Make the **stability gate (Claim 3)** and **regulatory-risk gate** prominent independent limitations — they are the cleanest distance from both references and the strongest §101 "practical application" hooks.
- **Recite the inter-agent kernel explicitly.** Claim the Fisher–Rao distance as an *edge weight between distinct agents*, with $\lambda/\Lambda$ *learned from human-override rationale embeddings*, to separate decisively from single-model calibration (B).
- **Keep eigenvector aggregation dependent or tightly qualified.** Because EigenTrust occupies bare eigenvector trust aggregation, claim ATVA's version only as **(calibrated multi-dimensional nodes + Fisher–Rao edges + stability/compliance gating)** — never the eigenvector step alone.
- **Anchor §101 in measurable effects.** Tie claims to the technical improvements in the intake form to satisfy *Alice* Step 2A Prong Two.
- **Demote textbook components.** CUSUM, Kalman, and Hedge belong in dependent claims as implementation detail, claimed in combination, never standalone.

---

*Privileged & confidential attorney work product. Prepared to support internal patent review and prosecution strategy. Not a legal opinion or a freedom-to-operate clearance; a registered practitioner should perform a formal search before filing. Prior-art characterizations are for differentiation and are not admissions.*
