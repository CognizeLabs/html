---
title: "Invention Disclosure Intake Form"
subtitle: "Adaptive Trust Vector Arbitration (ATVA)"
author: "Confidential — Attorney–Client Privileged"
date: "2026-06-09"
---

> **Instructions to inventor:** Complete every section. Fields marked _[fill in]_ require your input. This form is the intake record patent counsel uses to assess patentability and draft claims. **Do not publicly disclose, demonstrate, offer for sale, or publish the invention before speaking with counsel** — doing so can start statutory bar clocks (see Section 9).

---

## 1. Administrative

| Field | Entry |
|-------|-------|
| Invention title | Adaptive Trust Vector Arbitration (ATVA) |
| Internal docket / reference no. | _[fill in]_ |
| Disclosure date | 2026-06-09 |
| Primary inventor (name, title) | _[fill in]_ |
| Inventor email / phone | _[fill in]_ |
| Co-inventors (all who contributed to conception) | _[fill in]_ |
| Assignee / employer of record | _[fill in]_ |
| Business unit / product line | _[fill in]_ |
| Funding source (any govt/3rd-party funds?) | ☐ None ☐ Yes: _[fill in]_ |

---

## 2. Field of the Invention

Computer-implemented arbitration of conflicting outputs from multiple AI agents in regulated decision environments (e.g., healthcare-insurance claim adjudication, prior authorization, employer-sponsored benefit determination). Subfields: ensemble learning, multi-agent systems, confidence calibration, Bayesian/optimal estimation, spectral graph inference, online learning.

---

## 3. Problem Solved (technical problem, not business goal)

Multi-agent AI systems produce conflicting decisions with confidence scores that are **not comparable across agents** ("95% from Agent A" ≠ "95% from Agent B"), are poorly calibrated, give no measure of how *stable* a consensus is, and provide no structured way to detect regulatory non-compliance or to learn from human reviewer overrides. Existing arbitration (majority/weighted voting, mixture-of-experts, Bayesian arbitration, EigenTrust-style reputation) treats trust as a single scalar and cannot answer which confidence to trust, whether it is calibrated, or whether a recommendation is regulatorily valid.

---

## 4. Summary of the Invention (3–5 sentences, plain language)

ATVA represents each agent's trustworthiness as a six-dimensional **calibrated** trust vector and measures distances between agents on a Fisher–Rao statistical manifold whose geometry is learned from human overrides. It arbitrates by computing the **stationary distribution of a trust-affinity Markov operator** over the agents (graph-spectral influence) rather than by voting or averaging, then **gates its own output by the geometric stability of the consensus** (spectral gap × decision margin) and a regulatory-risk index — forcing escalation when the agreement is fragile or non-compliant. Agent reliability is tracked as a non-stationary hidden state by a mean-reverting Kalman filter, drift is detected by a CUSUM statistic in metric space, and dimension weights are updated online by a regret-bounded multiplicative-weights rule. The system outputs a final decision, a reconciled trust vector, a stability-gated confidence, a regulatory-risk index, and a variance-decomposition explanation naming the dimension that caused any disagreement.

---

## 5. Points of Novelty (what is new — the crux of the application)

Mark each as believed-novel and note the closest thing you are aware of.

| # | Novel feature | Believed novel? | Closest known approach |
|---|---------------|-----------------|------------------------|
| N1 | Six-dimensional **calibrated** trust vector with per-agent, per-dimension logistic calibration maps | ☐ yes | scalar confidence; temperature/Platt scaling (single scalar) |
| N2 | **Fisher–Rao regulatory-weighted metric** used as the affinity kernel between agents | ☐ yes | Fisher–Rao calibration of a *single* classifier |
| N3 | **Graph-spectral arbitration** = stationary distribution of a trust-affinity Markov operator | ☐ yes | EigenTrust (scalar P2P reputation eigenvector) |
| N4 | **Consensus Stability Score** = spectral gap × decision margin; forces escalation of fragile pluralities | ☐ yes | none known |
| N5 | **Kalman-tracked, mean-reverting reliability** + **CUSUM drift** detection in metric space | ☐ yes | static or EWMA reputation |
| N6 | **Hedge** dimension-reweighting with $O(\sqrt{T\ln D})$ regret bound | ☐ yes | offline retraining / fixed weights |
| N7 | **Stability-gated reconciliation + trust-ANOVA** root-cause of disagreement | ☐ yes | none known |
| N8 | **Human-override learning that reshapes the metric geometry itself** (not just scalar weights) | ☐ yes | RLHF reward model (scalar) |

---

## 6. Closest Known Prior Art (be candid — counsel must know)

| Reference | What it teaches | How ATVA differs |
|-----------|-----------------|------------------|
| EigenTrust (Kamvar et al., WWW 2003) | Global *scalar* trust per peer = principal eigenvector of normalized local-trust matrix; P2P file-authenticity reputation | Nodes carry calibrated 6-D trust vectors; edges use a learned Fisher–Rao kernel; outcome is gated by stability + regulatory risk; metric learned from overrides |
| Fisher–Rao post-hoc calibration (information-geometry calibration literature, incl. 2025 work) | Single-model probability outputs as points on a Fisher–Rao manifold; ALR calibration maps | Multi-agent *affinity kernel* in an arbitration graph; not single-model calibration |
| Multi-agent LLM confidence/consensus (2024–2025 research) | Deliberation/debate to improve calibration & reduce hallucination | No geometric trust metric, no spectral-gap stability gate, no regulatory-risk gate, no regret-bounded online learning |
| CUSUM (Page 1954) / Kalman (1960) / Hedge (Freund–Schapire 1997) | Standard change-detection / estimation / online-learning techniques | Used only as components inside the integrated arbitration; claimed in combination + application, not standalone |

---

## 7. Advantages and Measurable Technical Improvements

| Metric | Baseline (best prior) | ATVA target | How measured |
|--------|----------------------|-------------|--------------|
| Arbitration accuracy vs. ground truth | ~81% (weighted voting) | > 92% | retrospective audit |
| Hallucination rate ($C_F<0.5$) | ~18% (single agent) | < 11% (>40% reduction) | factual-confidence frequency |
| Regulatory compliance rate | ~94% | > 98% | RRI tier distribution |
| Human override rate (30-day rolling) | deployment baseline | > 25% reduction by day 90 | override event frequency |
| Decision stability (identical-query replay) | ~88% | > 95% | duplicate-query replay |
| Confidence calibration error | ~0.14 | < 0.08 | Brier score across dimensions |
| Fragile-plurality escalation | not detected | detected & escalated | CSS threshold trips |

*These measurable, technical effects are important for subject-matter eligibility (see Section 10).*

---

## 8. Enablement / Reduction to Practice

| Question | Answer |
|----------|--------|
| Conceived on (date) | _[fill in]_ |
| First written description (date) | 2026-06-09 (this disclosure + ATVA spec) |
| Reduced to practice? | ☐ No (conception only) ☐ Prototype ☐ Production |
| Code / simulation exists? | ☐ No ☐ Yes — location: _[fill in]_ |
| Benchmarks run? | ☐ No ☐ Yes — results: _[fill in]_ |
| Is the full algorithm described well enough for a skilled engineer to implement? | ☐ Yes — see ATVA_Algorithm_Disclosure (math, pseudocode, data structures) |

---

## 9. Public Disclosure / Bar-Date Status (CRITICAL)

| Question | Answer |
|----------|--------|
| Publicly disclosed (talk, paper, blog, demo)? | ☐ No ☐ Yes — date & venue: _[fill in]_ |
| Offered for sale or sold? | ☐ No ☐ Yes — date: _[fill in]_ |
| Shared with anyone outside under NDA? | ☐ No ☐ Yes — parties: _[fill in]_ |
| Planned disclosure within 12 months? | ☐ No ☐ Yes — date: _[fill in]_ |

> Any "yes" above can trigger a statutory bar (e.g., the U.S. one-year grace period; immediate loss of rights in absolute-novelty jurisdictions). **Flag this to counsel immediately.**

---

## 10. Patentability / Eligibility Notes for Counsel

- **§101 (Alice):** the invention is math-heavy; claims should be drafted to a *specific method tied to a practical application* (the regulated multi-agent decision system) with the **measurable technical improvements in Section 7** as the concrete effect. Avoid claiming the abstract math alone.
- **Filing posture:** recommend a **provisional** to secure priority now, given the fast-filling agent-orchestration patent landscape.
- **Claim architecture:** one broad system/method anchor claim + focused independents on N2 (Fisher–Rao affinity kernel), N4 (stability gate), N7 (stability-gated reconciliation); demote N5/N6 textbook components to dependent claims.
- **Prior-art rebuttal:** see the companion *Prior-Art Rebuttal Memo* (EigenTrust + Fisher–Rao calibration).

---

## 11. Drawings / Figures Available

☐ State diagram ☐ Architecture diagram ☐ Trust-vector / radar plot ☐ Affinity-graph diagram ☐ Worked numerical example ☐ Telemetry schema — _list locations:_ _[fill in]_

---

## 12. Signatures

| Role | Name | Signature | Date |
|------|------|-----------|------|
| Inventor | _[fill in]_ | | |
| Co-inventor | _[fill in]_ | | |
| Witness (read & understood) | _[fill in]_ | | |
| Reviewing attorney | _[fill in]_ | | |

---

*Privileged & confidential. Prepared for internal patent review. Not a filed application or legal opinion.*
