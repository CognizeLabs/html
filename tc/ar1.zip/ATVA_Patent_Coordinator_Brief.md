---
title: "Patent Coordinator Meeting Brief"
subtitle: "Adaptive Trust Vector Arbitration (ATVA)"
author: "Confidential — Internal Use Only"
date: "2026-06-09"
---

> **Purpose of this document:** A plain-language briefing to support an initial conversation with an enterprise patent coordinator. This is not a formal patent application or legal opinion. It is a structured intake summary covering what was invented, why it is novel, what the closest prior art is, and a suggested filing strategy.

---

## 1. Invention Name and One-Line Summary

**Invention:** Adaptive Trust Vector Arbitration (ATVA)

**One-line summary:**
A novel algorithm that reconciles conflicting outputs from multiple AI agents in regulated insurance environments by replacing single confidence scores with a six-dimensional trust model, arbitrating through graph-spectral influence, and gating decisions on the geometric stability of the consensus — with the system learning and improving from human reviewer overrides over time.

---

## 2. Business Context — Where This Lives

This invention is designed for a **broker and employer portal** operated by a healthcare insurance company. The users are **brokers** and **employers** — not individual members.

**The kinds of tasks the system handles:**

- A broker asks: *"What is my commission for employer group XYZ this quarter?"*
- An employer asks: *"Which plan options are available for my employee group?"*
- A broker runs a sales quote for a new employer group
- A broker or employer updates enrollment — adding, changing, or removing members
- A broker asks about benefits and coverage rules for a specific employer plan

**The AI architecture behind these tasks:**

Each query is handled by multiple AI agents working in parallel. For example, a compensation query might be handled by:

- A **primary agent** that reads the broker's commission statement PDF
- An **evaluator agent** that queries the compensation management database directly

These two agents can — and do — produce different answers. The system needs a principled, auditable way to decide which answer to trust, or whether to escalate to a human reviewer.

**That decision mechanism is ATVA.**

---

## 3. The Problem ATVA Solves

### Problem 1 — Confidence scores are not comparable across agents

When Agent A returns a confidence of 92% and Agent B returns 88%, the system currently has no way to know which score to trust. Agent A may be chronically overconfident — historically right only 70% of the time when it says 92%. Agent B may be well-calibrated — genuinely right 88% of the time. A single number carries no information about whether it means anything.

### Problem 2 — No way to detect when a consensus is fragile

If three agents vote Approve / Approve / Deny, a majority-vote system approves. But what if the two approving agents are barely above the threshold and the dissenting agent has very strong evidence? The system has no mechanism to detect that the consensus is fragile and should be escalated.

### Problem 3 — No regulatory risk awareness at decision time

Before showing an answer to a broker or employer, the system should check: is this answer consistent with current ACA rules, ERISA requirements, and state mandates? Currently, there is no automated gate for this at the point of arbitration.

### Problem 4 — No learning from human corrections

When a human reviewer corrects the system, that correction currently improves nothing. The agents do not become better calibrated. The system does not learn which dimensions of confidence matter most for which types of decisions.

### Problem 5 — No audit trail for *why* a decision was made

Regulators and compliance teams can see *what* the system decided. They cannot see *why* — which agents agreed, which dissented, how confident the consensus was, and whether a human was appropriately involved.

---

## 4. What ATVA Does — Plain English

ATVA sits between the agents and the user. When agents return conflicting answers, ATVA runs the following process:

**Step 1 — Give every agent a six-part report card instead of one score.**
Each agent is scored on: factual accuracy, retrieval quality, regulatory alignment, information freshness, historical precedent agreement, and past agreement with human reviewers. This produces a six-dimensional trust vector per agent.

**Step 2 — Normalize scores so they are actually comparable across agents.**
Each agent's scores are passed through a learned correction map that accounts for that agent's historical calibration. An overconfident agent's scores are compressed. An underconfident agent's scores are boosted. Now "88% from Agent A" and "88% from Agent B" actually mean the same thing.

**Step 3 — Build a trust network, not a vote.**
Agents are connected in a graph where the strength of the connection depends on how similar their trust vectors are and how reliable each agent has been. The final influence of each agent is computed as the stationary distribution of this network — meaning an agent that is trustworthy *and* agrees with other trustworthy agents carries more weight than a lone confident outlier.

**Step 4 — Check how stable the consensus is.**
Even if one answer leads, the system measures how easily that result could flip. A mathematically fragile consensus — where the margin is thin — is automatically escalated regardless of which answer was leading.

**Step 5 — Run a regulatory risk check.**
Before the answer is shown, the system checks alignment with applicable regulatory frameworks. High-risk outputs are blocked and routed to a compliance officer.

**Step 6 — Produce a decision with a full explanation.**
The output includes: the final answer, a reconciled confidence score, and a structured explanation naming which trust dimension caused the disagreement (e.g., *"agents split on regulatory grounds"* or *"PDF source was 47 days old"*).

**Step 7 — Learn from human corrections.**
When a reviewer overrides the system, ATVA updates the calibration of each agent, adjusts the weights it places on each dimension, and improves its reliability tracking. Over time, override rates decrease.

---

## 5. What We Believe Is Patentable

The following four items are our strongest candidates for independent patent claims. Each addresses a limitation that no existing system resolves.

---

### Claim Candidate 1 — The Six-Dimensional Trust Confidence Vector with Online Calibration

**What it is:**
Each AI agent produces a trust vector with six independently computed dimensions: factual confidence, retrieval confidence, regulatory confidence, temporal confidence, precedent confidence, and human alignment confidence. Each dimension is passed through a per-agent, per-dimension correction map whose parameters are updated in real time from human override signals.

**Why it is novel:**
No existing multi-agent system decomposes trust into these six dimensions. No existing system applies per-agent, per-dimension calibration that learns online from human overrides at inference time — as opposed to periodic offline retraining.

**What it replaces:**
A single scalar confidence score that is not comparable across agents and does not reflect the multi-dimensional nature of reliability in regulated decisions.

---

### Claim Candidate 2 — Consensus Stability Score as a Hard Escalation Gate

**What it is:**
A score computed from two factors: how quickly the influence network converges (the spectral gap of the affinity matrix) and how wide the margin is between the top two decision options. When this score falls below a threshold, the system forces escalation — regardless of which answer was leading.

**Why it is novel:**
No prior system detects *geometrically fragile* consensus among AI agents and uses it as a mandatory escalation trigger. Existing systems either take the plurality answer or compute a simple margin — they do not combine spectral convergence speed with decision margin as a stability measure.

**Why this matters in practice:**
A 51% / 49% split in agent influence looks like a "win" for the leading answer. A 90% / 10% split is a genuine consensus. ATVA can tell the difference and act accordingly. This prevents high-stakes insurance decisions from being made on the basis of a coin flip.

---

### Claim Candidate 3 — Stability-Gated Confidence with Variance-Decomposition Root Cause

**What it is:**
The final confidence score shown is the product of the weighted trust mass of the winning agents *and* the consensus stability score. Additionally, the system runs a variance decomposition across trust dimensions to identify which specific dimension caused the disagreement — and includes this in the audit record.

**Why it is novel:**
No existing system multiplies confidence by stability — meaning high agent confidence combined with low stability correctly produces a low final confidence rather than a misleadingly high one. The variance decomposition that names the root-cause dimension is also novel in this application.

**What it produces:**
An audit record that tells a compliance reviewer not just *what* was decided but *why agents disagreed* — for example: *"Primary conflict was on regulatory confidence (agents disagreed on which mandate applied) rather than on factual confidence (both agreed on the underlying data)."*

---

### Claim Candidate 4 — The Integrated System as a Whole

**What it is:**
The complete pipeline: six-dimensional calibrated trust vectors → Fisher-Rao inter-agent distance metric → trust-affinity graph → spectral influence arbitration → stability gate → regulatory risk gate → stability-gated reconciled confidence → variance-decomposition explanation → online learning from human overrides — deployed as an end-to-end arbitration system for regulated multi-agent AI decisions.

**Why it is novel:**
No single prior system combines these mechanisms. The specific combination — particularly the regulatory compliance gate, the stability-forced escalation, and the human-override-driven online calibration — tied to a regulated insurance context with measurable technical improvements, constitutes a novel integrated invention.

---

## 6. Prior Art We Are Aware Of — and How We Differ

It is important to be transparent with the coordinator about what we found. The following are the references most likely to be cited against us.

---

### Reference 1 — EigenTrust (Stanford, 2003)

**What it is:**
An algorithm for peer-to-peer file-sharing networks where each peer's global trust score is the principal eigenvector of a matrix of local trust ratings. Used to reduce inauthentic file downloads.

**Why it will be cited:**
Our arbitration uses a similar eigenvector / stationary distribution mechanism.

**How we differ:**

| EigenTrust | ATVA |
|---|---|
| Operates on a single scalar trust value per peer | Operates on a six-dimensional calibrated trust vector per agent |
| Designed for file authenticity reputation in P2P networks | Designed for regulated insurance decisions in a multi-agent AI system |
| No calibration of trust scores | Per-agent, per-dimension online calibration |
| No distance metric between agents | Fisher-Rao statistical geometry as the edge kernel |
| No stability gate | Consensus Stability Score forces escalation of fragile results |
| No regulatory risk gate | Regulatory risk index blocks non-compliant outputs |
| No learning from human overrides | Full online learning cascade on every override |
| Output is a peer ranking | Output is a gated decision with reconciled confidence and explanation |

**What to say:** *"EigenTrust is a building block we are aware of. Our differentiator is everything built on top of and around that mechanism — the multidimensional calibrated trust model, the stability gate, the regulatory gate, and the learning loop. We are not claiming eigenvector aggregation. We are claiming the specific integrated system."*

---

### Reference 2 — Fisher-Rao Post-Hoc Calibration (2025 research)

**What it is:**
Academic research applying Fisher-Rao information geometry to calibrate the probability outputs of a single machine learning model. Treats a classifier's outputs as points on a statistical manifold.

**Why it will be cited:**
Our distance metric uses Fisher-Rao geometry.

**How we differ:**

| Fisher-Rao calibration paper | ATVA |
|---|---|
| Applied to one model's own outputs | Applied as a distance metric *between* separate agents |
| Used for post-hoc calibration of a single classifier | Used as the edge kernel in a multi-agent affinity graph |
| No multi-agent setting | Defines how similar two agents' trust vectors are |
| Static — applied once after training | Dynamic — metric coupling matrix is learned from human override rationales at runtime |
| No regulatory weighting | Importance weights per dimension reflect regulatory context |

**What to say:** *"We are aware of Fisher-Rao calibration work for single models. Our differentiator is using it as the distance function between agents in a trust graph — a purpose the existing literature does not address."*

---

## 7. The Evaluator Agent Pattern — An Additional Claim Surface

Beyond the core ATVA algorithm, our implementation introduces a specific architectural pattern that may have independent claim value.

**What it is:**
For each primary AI agent (e.g., a compensation agent reading a PDF), a corresponding evaluator agent is deployed that retrieves the same information from a different authoritative source (e.g., a live database API). ATVA then arbitrates between the two using the trust vector framework.

**Example — Broker Compensation:**
- Primary agent reads the broker's commission statement PDF
- Evaluator agent queries the compensation management system API
- ATVA compares both outputs, identifies which source is more trustworthy for this specific query, and either returns the authoritative answer or escalates the discrepancy

**Why this may be patentable:**
The specific combination of dual-source verification (PDF vs. authoritative DB/API) with ATVA arbitration using the six-dimensional trust vector, in a regulated insurance context, with evaluator agents configured via a declarative specification rather than custom code — is a novel application pattern.

**Other evaluator agent pairs in our system:**

| Domain | Primary Agent Source | Evaluator Agent Source |
|---|---|---|
| Broker compensation | Commission statement PDF | Compensation management DB/API |
| Benefits and coverage | Benefits document RAG | Plan structure database |
| Enrollment eligibility | Enrollment form data | Eligibility rules engine API |
| Sales quote | Rate table documents | Live rating engine API |
| Plan recommendation | Employee census + docs | Plan availability DB |

---

## 8. Measurable Technical Improvements

These are important for demonstrating that the invention produces a concrete technical effect — not just an abstract mathematical method.

| What we measure | Expected improvement | How it is measured |
|---|---|---|
| Decision accuracy vs. audited ground truth | From ~81% to over 92% | Retrospective audit of historical decisions |
| Hallucination rate | More than 40% reduction | Frequency of low factual-confidence scores |
| Human override rate (30-day rolling) | More than 25% reduction by day 90 | Override event frequency over time |
| Regulatory compliance rate | From ~94% to over 98% | Regulatory risk index tier distribution |
| Decision stability on identical queries | From ~88% to over 95% | Duplicate query replay testing |
| Fragile consensus detection | Previously undetected — now gated | Consensus Stability Score threshold events |
| Explainability of disagreement | Zero to 100% of decisions | Presence of root-cause dimension in every audit record |

---

## 9. What Is Not Patentable — Building Blocks to Acknowledge

The following components within ATVA are based on well-established prior work. We use them as components inside the integrated system. We would claim their *specific application* inside ATVA as dependent claims, not as standalone inventions.

| Component | Original source | Our position |
|---|---|---|
| CUSUM change-point detection | Page, 1954 | Prior art — claimed only as a component of the drift detector within ATVA |
| Kalman filter state estimation | Kalman, 1960 | Prior art — claimed only as the reliability tracking mechanism within ATVA |
| Multiplicative weights / Hedge algorithm | Freund and Schapire, 1997 | Prior art — claimed only as the dimension reweighting mechanism within ATVA |
| Eigenvector / stationary distribution aggregation | EigenTrust, Kamvar et al., 2003 | Prior art — claimed in the context of calibrated multi-dimensional trust nodes with Fisher-Rao edges and stability gating |

---

## 10. Suggested Filing Strategy

| Step | Action | Timing |
|---|---|---|
| 1 | File a **provisional patent application** covering the full integrated ATVA system | Immediately — locks in priority date |
| 2 | Commission a professional patentability search | Within 30 days of provisional filing |
| 3 | File **non-provisional #1** — focused on the six-dimensional trust vector with online calibration and the consensus stability escalation gate | Within 12 months of provisional |
| 4 | File **non-provisional #2** — focused on the evaluator agent framework with ATVA arbitration in regulated insurance | Within 12 months of provisional |
| 5 | Optional non-provisional #3 — the integrated system as a whole | Within 12 months of provisional |

**Why file the provisional now:**
The multi-agent AI orchestration patent space is filling rapidly. At least one major financial firm (Broadridge) has already received a US patent on LLM orchestration of ML agents (US Patent 12,061,970). A provisional application establishes our priority date immediately at low cost while we continue development and prepare the full non-provisional applications.

---

## 11. Questions to Ask the Coordinator

These are the questions we recommend raising during the meeting:

1. Based on this brief, do you see any additional prior art we should be aware of before we invest in a full search?

2. Given the §101 / *Alice* landscape for software and mathematical algorithm patents in 2026, how would you recommend we frame the claims to foreground the practical application over the mathematical method?

3. Would you recommend filing in the US only, or pursuing PCT (international) filing given that our platform may expand to other markets?

4. Are there any aspects of the evaluator agent pattern that you believe would warrant a separate independent application rather than a dependent claim in the main application?

5. What is your assessment of the timeline and cost for a full patentability search and non-provisional preparation?

---

## 12. Supporting Documents Available

The following technical documents are available to share with the coordinator on request:

| Document | Contents |
|---|---|
| ATVA Algorithm Disclosure | Full mathematical definitions, pseudocode, data structures, worked numerical example, complexity analysis, novelty summary |
| Invention Disclosure Intake Form | Formal intake record with all inventor fields, bar-date status, reduction to practice status |
| Prior Art Rebuttal Memo | Claim-by-claim differentiation of EigenTrust and Fisher-Rao calibration references with §103 combination rebuttal arguments |

---

*Confidential — internal use only. Prepared to support an initial patent coordinator meeting. Not a legal opinion, not a filed patent application, and not a freedom-to-operate clearance. All prior-art characterizations are for differentiation purposes only and are not admissions of prior art.*
